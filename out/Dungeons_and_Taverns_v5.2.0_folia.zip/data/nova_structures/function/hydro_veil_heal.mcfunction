effect give @s minecraft:regeneration 1 6 true

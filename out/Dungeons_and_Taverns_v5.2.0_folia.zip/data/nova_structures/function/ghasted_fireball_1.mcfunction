summon minecraft:fireball ~ ~ ~ {Tags:["dnt_ghasted_fireball"]}
kill @s

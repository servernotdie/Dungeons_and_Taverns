attribute @s minecraft:spawn_reinforcements modifier add minecraft:leader_zombie_bonus 0.625 add_value
attribute @s minecraft:max_health modifier add minecraft:leader_zombie_bonus 2.5 add_multiplied_total
attribute @s minecraft:max_health base set 50

summon minecraft:fireball ~ ~ ~ {Tags:["dnt_ghasted_fireball"],ExplosionPower:1}
kill @s
summon minecraft:fireball ~ ~ ~ {Tags:["dnt_ghasted_fireball"],ExplosionPower:3}
kill @s
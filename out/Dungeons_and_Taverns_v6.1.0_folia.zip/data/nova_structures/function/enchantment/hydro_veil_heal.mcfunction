particle minecraft:splash ~ ~2 ~ 0.8 0.8 0.8 0 25 normal
playsound minecraft:ambient.underwater.loop.additions neutral @a ~ ~ ~ 0.1 2
effect give @s minecraft:regeneration 1 6 true

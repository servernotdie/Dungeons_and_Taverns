summon minecraft:fireball ~ ~ ~ {Tags:["dnt_ghasted_fireball"],ExplosionPower:2}
kill @s
effect clear @s minecraft:levitation
advancement revoke @s only nova_structures:phantom_boss_make_fall
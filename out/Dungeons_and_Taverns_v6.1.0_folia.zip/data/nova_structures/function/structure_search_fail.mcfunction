tellraw @s {"fallback":"No Minecraft or DnT Structure here...","font":"uniform","translate":"search_structure.dnt.function_unknown"}

title @s actionbar {"fallback":"No Minecraft or DnT Structure here...","translate":"search_structure.dnt.function_unknown"}
execute if predicate {predicate:{structures:"nova_structures:well_birch"},type:"minecraft:location_check"} run tell @s nova_structures:well_birch

execute if predicate {predicate:{structures:"nova_structures:well_cherry"},type:"minecraft:location_check"} run tell @s nova_structures:well_cherry

execute if predicate {predicate:{structures:"nova_structures:well_dappled"},type:"minecraft:location_check"} run tell @s nova_structures:well_dappled

execute if predicate {predicate:{structures:"nova_structures:well_dark_oak"},type:"minecraft:location_check"} run tell @s nova_structures:well_dark_oak

execute if predicate {predicate:{structures:"nova_structures:well_desert"},type:"minecraft:location_check"} run tell @s nova_structures:well_desert

execute if predicate {predicate:{structures:"nova_structures:well_jungle"},type:"minecraft:location_check"} run tell @s nova_structures:well_jungle

execute if predicate {predicate:{structures:"nova_structures:well_mangrove"},type:"minecraft:location_check"} run tell @s nova_structures:well_mangrove

execute if predicate {predicate:{structures:"nova_structures:well_oak"},type:"minecraft:location_check"} run tell @s nova_structures:well_oak

execute if predicate {predicate:{structures:"nova_structures:well_pale"},type:"minecraft:location_check"} run tell @s nova_structures:well_pale

execute if predicate {predicate:{structures:"nova_structures:well_savanna"},type:"minecraft:location_check"} run tell @s nova_structures:well_savanna

execute if predicate {predicate:{structures:"nova_structures:well_snowy"},type:"minecraft:location_check"} run tell @s nova_structures:well_snowy

execute if predicate {predicate:{structures:"nova_structures:well_spruce"},type:"minecraft:location_check"} run tell @s nova_structures:well_spruce

execute if predicate {predicate:{structures:"nova_structures:well_swamp"},type:"minecraft:location_check"} run tell @s nova_structures:well_swamp


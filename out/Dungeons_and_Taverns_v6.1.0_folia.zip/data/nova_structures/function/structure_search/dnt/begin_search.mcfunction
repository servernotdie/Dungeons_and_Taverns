execute if predicate {predicate:{structures:"#nova_structures:nova_structures_end"},type:"minecraft:location_check"} run function nova_structures:structure_search/dnt/end

execute if predicate {predicate:{structures:"#nova_structures:nova_structures_nether"},type:"minecraft:location_check"} run function nova_structures:structure_search/dnt/nether

execute if predicate {predicate:{structures:"#nova_structures:nova_structures_overworld"},type:"minecraft:location_check"} run function nova_structures:structure_search/dnt/overworld

execute if predicate {predicate:{structures:"#nova_structures:nova_structures_underground"},type:"minecraft:location_check"} run function nova_structures:structure_search/dnt/underground

execute if predicate {predicate:{structures:"#nova_structures:nova_structures_underwater"},type:"minecraft:location_check"} run function nova_structures:structure_search/dnt/underwater
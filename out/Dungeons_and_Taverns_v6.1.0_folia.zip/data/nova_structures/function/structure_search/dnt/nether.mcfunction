execute if predicate {predicate:{structures:"#nova_structures:nether_towers"},type:"minecraft:location_check"} run function nova_structures:structure_search/dnt/nether_skeleton_zones

execute if predicate {predicate:{structures:"nova_structures:piglin_camp"},type:"minecraft:location_check"} run tell @s nova_structures:piglin_camp

execute if predicate {predicate:{structures:"nova_structures:piglin_camp_collony"},type:"minecraft:location_check"} run tell @s nova_structures:piglin_camp_collony

execute if predicate {predicate:{structures:"nova_structures:hamlet"},type:"minecraft:location_check"} run tell @s nova_structures:hamlet

execute if predicate {predicate:{structures:"nova_structures:nether_keep"},type:"minecraft:location_check"} run tell @s nova_structures:nether_keep

execute if predicate {predicate:{structures:"nova_structures:nether_port"},type:"minecraft:location_check"} run tell @s nova_structures:nether_port

execute if predicate {predicate:{structures:"nova_structures:piglin_donjon"},type:"minecraft:location_check"} run tell @s nova_structures:piglin_donjon

execute if predicate {predicate:{structures:"nova_structures:piglin_outstation"},type:"minecraft:location_check"} run tell @s nova_structures:piglin_outstation

execute if predicate {predicate:{structures:"nova_structures:sealing_halls"},type:"minecraft:location_check"} run tell @s nova_structures:sealing_halls
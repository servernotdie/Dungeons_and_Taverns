execute if predicate {predicate:{structures:"nova_structures:cave_chamber"},type:"minecraft:location_check"} run tell @s nova_structures:cave_chamber

execute if predicate {predicate:{structures:"nova_structures:cave_chamber_archeology_ruins"},type:"minecraft:location_check"} run tell @s nova_structures:cave_chamber_archeology_ruins

execute if predicate {predicate:{structures:"nova_structures:cave_chamber_colony"},type:"minecraft:location_check"} run tell @s nova_structures:cave_chamber_colony

execute if predicate {predicate:{structures:"nova_structures:cave_chamber_dungeon_colony"},type:"minecraft:location_check"} run tell @s nova_structures:cave_chamber_dungeon_colony
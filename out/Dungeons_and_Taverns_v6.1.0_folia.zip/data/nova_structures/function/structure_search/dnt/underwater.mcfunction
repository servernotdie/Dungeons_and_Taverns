execute if predicate {predicate:{structures:"nova_structures:small_conduit_ruin_cold"},type:"minecraft:location_check"} run tell @s nova_structures:small_conduit_ruin_cold

execute if predicate {predicate:{structures:"nova_structures:small_conduit_ruin_warm"},type:"minecraft:location_check"} run tell @s nova_structures:small_conduit_ruin_warm

execute if predicate {predicate:{structures:"nova_structures:conduit_ruin"},type:"minecraft:location_check"} run tell @s nova_structures:conduit_ruin

execute if predicate {predicate:{structures:"nova_structures:trident_trial_monument"},type:"minecraft:location_check"} run tell @s nova_structures:trident_trial_monument
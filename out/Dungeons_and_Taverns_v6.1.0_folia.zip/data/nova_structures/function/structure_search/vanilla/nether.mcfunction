execute if predicate {predicate:{structures:"minecraft:bastion_remnant"},type:"minecraft:location_check"} run tell @s minecraft:bastion_remnant

execute if predicate {predicate:{structures:"minecraft:fortress"},type:"minecraft:location_check"} run tell @s minecraft:fortress

execute if predicate {predicate:{structures:"minecraft:nether_fossil"},type:"minecraft:location_check"} run tell @s minecraft:nether_fossil

execute if predicate {predicate:{structures:"minecraft:ruined_portal"},type:"minecraft:location_check"} run tell @s minecraft:ruined_portal

execute if predicate {predicate:{structures:"minecraft:ruined_portal_desert"},type:"minecraft:location_check"} run tell @s minecraft:ruined_portal_desert

execute if predicate {predicate:{structures:"minecraft:ruined_portal_jungle"},type:"minecraft:location_check"} run tell @s minecraft:ruined_portal_jungle

execute if predicate {predicate:{structures:"minecraft:ruined_portal_mountain"},type:"minecraft:location_check"} run tell @s minecraft:ruined_portal_mountain

execute if predicate {predicate:{structures:"minecraft:ruined_portal_nether"},type:"minecraft:location_check"} run tell @s minecraft:ruined_portal_nether

execute if predicate {predicate:{structures:"minecraft:ruined_portal_ocean"},type:"minecraft:location_check"} run tell @s minecraft:ruined_portal_ocean

execute if predicate {predicate:{structures:"minecraft:ruined_portal_swamp"},type:"minecraft:location_check"} run tell @s minecraft:ruined_portal_swamp
execute if predicate {predicate:{structures:"minecraft:monument"},type:"minecraft:location_check"} run tell @s minecraft:monument

execute if predicate {predicate:{structures:"minecraft:ocean_ruin_cold"},type:"minecraft:location_check"} run tell @s minecraft:ocean_ruin_cold

execute if predicate {predicate:{structures:"minecraft:ocean_ruin_warm"},type:"minecraft:location_check"} run tell @s minecraft:ocean_ruin_warm

execute if predicate {predicate:{structures:"minecraft:shipwreck"},type:"minecraft:location_check"} run tell @s minecraft:shipwreck

execute if predicate {predicate:{structures:"minecraft:shipwreck_beached"},type:"minecraft:location_check"} run tell @s minecraft:shipwreck_beached
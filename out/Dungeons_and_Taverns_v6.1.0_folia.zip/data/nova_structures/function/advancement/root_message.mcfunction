title @s subtitle {"color":"gold","fallback":"Install DnT as a Resource Pack for extra features!","shadow_color":-13426176,"translate":"advancement.dnt.root.title"}

title @s title {translate:"⚠⚠⚠",with:[{atlas:"minecraft:items",sprite:"dnt:item/16x_logo"}]}
execute if entity @s[gamemode=survival] run effect clear @s minecraft:bad_omen
execute if entity @s[gamemode=survival] run effect give @s minecraft:bad_omen 6000 4 false